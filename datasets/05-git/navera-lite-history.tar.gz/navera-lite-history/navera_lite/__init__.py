"""NAVERA Lite (history of mission 05). Course code, not NAVERA code."""
