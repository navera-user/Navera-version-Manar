"""navera_lite/geo.py — distances for NAVERA Lite. Course code (it is not NAVERA code)."""
import math

EARTH_RADIUS_M = 6371000.0          # mean radius of the sphere (m)


def flat_distance_m(p, q):
    """Distance in metres between two points given as (east_m, north_m)."""
    return math.hypot(q[0] - p[0], q[1] - p[1])


def haversine_m(lat1, lon1, lat2, lon2):
    """Great-circle distance in metres on a sphere (latitudes and longitudes in degrees)."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * 6371000.0 * math.asin(math.sqrt(h))


def metres_per_degree_lat():
    """Length of one degree of latitude on the sphere (m)."""
    return EARTH_RADIUS_M * math.pi / 180.0


def metres_per_degree_lon(lat_deg):
    """Length of one degree of longitude at this latitude (m)."""
    return metres_per_degree_lat() * math.cos(math.radians(lat_deg))
