"""navera_lite/settings.py — read navera_lite.yaml. Course code (it is not NAVERA code)."""
DEFAULTS = {"max_speed_mps": 100.0, "gps_jump_margin_m": 50.0, "gps_timeout_s": 3.0}
SETTINGS_FILE = "navera_lite.yaml"


def load_settings(path=SETTINGS_FILE):
    """DEFAULTS, updated by the `key: value` lines of the file (values as floats)."""
    out = dict(DEFAULTS)
    try:
        with open(path) as f:
            lines = f.readlines()
    except FileNotFoundError:
        return out
    for raw in lines:
        text = raw.split("#")[0].strip()
        key, _, value = text.partition(":")
        if value.strip():
            out[key.strip()] = float(value)
    return out


def check_settings(s):
    """The broken rules of a settings dict, as sentences (an empty list when all is well)."""
    problems = []
    for key in ("max_speed_mps", "gps_jump_margin_m", "gps_timeout_s"):
        if s[key] <= 0:
            problems.append(f"{key} must be > 0, got {s[key]}")
    return problems
