"""navera_lite/guard.py — the jump gate of mission 01. Course code (it is not NAVERA code).

A refused fix never becomes the trusted one: otherwise a spoofer would only need one refusal to
move the reference. The gate widens with the time since the last TRUSTED fix.
"""
from navera_lite.geo import flat_distance_m


def gate_ok(last_xy, new_xy, elapsed_s, v_max_mps, margin_m):
    """True if a fix at new_xy is reachable from the trusted fix last_xy (metres, east/north)."""
    return flat_distance_m(last_xy, new_xy) <= v_max_mps * elapsed_s + margin_m


class JumpGate:
    """Remembers the last trusted fix and refuses the fixes the vehicle could not have reached."""

    def __init__(self, v_max_mps=100.0, margin_m=50.0):
        self.v_max_mps = v_max_mps
        self.margin_m = margin_m
        self.last_xy = None          # the last trusted fix (m)
        self.last_t_s = None         # its time (s)
        self.prev_t_s = None         # time of the previous fix, accepted or not (s)
        self.refused_since_s = None  # time of the first refusal in a row (s)

    def check(self, t_s, xy):
        """True if the fix at time t_s is accepted; an accepted fix becomes the trusted one."""
        if self.last_xy is None:
            self.last_xy, self.last_t_s, self.prev_t_s = xy, t_s, t_s
            return True
        elapsed_s = t_s - self.prev_t_s
        self.prev_t_s = t_s
        ok = gate_ok(self.last_xy, xy, elapsed_s, self.v_max_mps, self.margin_m)
        if ok:
            self.last_xy, self.last_t_s = xy, t_s
            self.refused_since_s = None
        elif self.refused_since_s is None:
            self.refused_since_s = t_s
        return ok

    def refused_for_s(self, now_s):
        """Seconds since GPS was first refused (0.0 while it is accepted)."""
        return 0.0 if self.refused_since_s is None else now_s - self.refused_since_s

    def status(self):
        """One line for the operator."""
        if self.last_xy is None:
            return "no trusted fix yet"
        e, n = self.last_xy
        return f"trusted fix at E {e:.0f} m, N {n:.0f} m (t = {self.last_t_s:.1f} s)"


def count_refused(fixes, dt_s, v_max_mps=100.0, margin_m=50.0):
    """How many fixes the gate refuses; fixes[0] is trusted, then one fix every dt_s seconds."""
    gate = JumpGate(v_max_mps, margin_m)
    gate.check(0.0, fixes[0])
    refused = 0
    for i in range(1, len(fixes)):
        if not gate.check(i * dt_s, fixes[i]):
            refused += 1
    return refused
