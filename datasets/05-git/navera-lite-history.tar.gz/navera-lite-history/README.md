# NAVERA Lite — history

NAVERA Lite is the small navigation stack written for the NAVERA Academy course. This repository is
a teaching history for mission 05: the people, dates and commits are invented, and the code is the
course's own (it is not NAVERA code). Missions 06 onwards build the full stack.

## What it does

Each GPS fix you recieve is checked by the jump gate (`navera_lite/guard.py`): a fix farther from
the last trusted fix than the vehicle can fly in the elapsed time, plus a margin, is refused.

## Settings

The gate's values are in `navera_lite.yaml` (ROS 2 params-file format). Change them only with a
measurement that shows why.

## Tests

    python3 -m pytest -q tests

## Reporting a bug

Say what you ran, what you expected, what you got, and the commit (`git log -1 --oneline`).

## Review rule

Every change is read by a second person before it enters `main`. Small commits, one concern each.
