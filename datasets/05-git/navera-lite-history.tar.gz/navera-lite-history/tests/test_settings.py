from navera_lite.settings import DEFAULTS, check_settings, load_settings


def test_file_values_override_defaults(tmp_path):
    p = tmp_path / "s.yaml"
    p.write_text("/**:\n  ros__parameters:\n    gps_jump_margin_m: 20.0   # tight\n")
    s = load_settings(str(p))
    assert s["gps_jump_margin_m"] == 20.0
    assert s["max_speed_mps"] == DEFAULTS["max_speed_mps"]


def test_check_settings():
    assert check_settings(DEFAULTS) == []
    bad = dict(DEFAULTS, gps_jump_margin_m=-5.0)
    assert check_settings(bad) == ["gps_jump_margin_m must be > 0, got -5.0"]
