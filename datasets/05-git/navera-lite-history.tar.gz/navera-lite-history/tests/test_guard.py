from navera_lite.guard import JumpGate, count_refused, gate_ok
from navera_lite.settings import load_settings


def test_gate_on_the_limit_is_accepted():
    assert gate_ok((0, 0), (150, 0), 1.0, 100.0, 50.0)


def test_gate_just_beyond_the_limit_is_refused():
    assert not gate_ok((0, 0), (151, 0), 1.0, 100.0, 50.0)


def test_jump_gate_refuses_a_500_m_jump():
    s = load_settings()
    gate = JumpGate(s["max_speed_mps"], s["gps_jump_margin_m"])
    assert gate.check(0.0, (0, 0))
    assert not gate.check(1.0, (500, 0))


def test_count_refused_without_a_jump():
    assert count_refused([(0, 0), (10, 0), (20, 0), (30, 0)], 1.0) == 0


def test_status_line():
    gate = JumpGate(100.0, 50.0)
    assert gate.status() == "no trusted fix yet"
    gate.check(2.0, (10.0, 20.0))
    assert "E 10 m" in gate.status()


def test_refused_for_s():
    gate = JumpGate(100.0, 50.0)
    gate.check(0.0, (0, 0))
    gate.check(1.0, (500, 0))
    gate.check(2.0, (500, 0))
    assert gate.refused_for_s(3.0) == 2.0
