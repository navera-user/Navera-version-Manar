from navera_lite.geo import flat_distance_m, haversine_m, metres_per_degree_lat, metres_per_degree_lon


def test_flat_distance_3_4_5():
    assert flat_distance_m((0, 0), (3, 4)) == 5.0


def test_london_paris():
    assert abs(haversine_m(51.5074, -0.1278, 48.8566, 2.3522) - 343556) < 1


def test_haversine_is_symmetric():
    a = haversine_m(1.2921, 103.8198, -33.9249, 18.4241)
    b = haversine_m(-33.9249, 18.4241, 1.2921, 103.8198)
    assert abs(a - b) < 1e-6


def test_longitude_degree_at_60_north():
    assert abs(metres_per_degree_lon(60.0) - metres_per_degree_lat() / 2) < 1e-6


def test_degree_of_latitude():
    assert abs(metres_per_degree_lat() - 111195) < 1
