# Changelog

## v0.2 (candidate, 2026-08-18)
- settings come from navera_lite.yaml
- count_refused() for replay tests
- JumpGate.status() and refused_for_s() for the operator

## v0.1 (2026-03-27)
- flat_distance_m, haversine_m
- the jump gate: gate_ok, JumpGate
